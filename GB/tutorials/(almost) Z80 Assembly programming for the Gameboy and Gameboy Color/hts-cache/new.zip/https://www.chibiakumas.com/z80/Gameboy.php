<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>




  
  
  
  <link rel="stylesheet" type="text/css" href="darkmode.css">




  
  
  
  <meta content="text/html;charset=ISO-8859-1" http-equiv="Content-Type">



  
  
  
  <title>gbZ80 Assembly programming for the Gameboy and Gameboy Color's</title>
</head>


<body>




<h1 class="green" style="text-align: center;">(almost)
Z80
Assembly programming for the Gameboy and Gameboy Color</h1>




<table style="text-align: left; width: 100%;" border="0" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;"> The Gameboys do
not
use a Z80... some people say they do, but those
people are wrong! it has MANY features of a Z80... but MANY others are
weird... and some are even BUGGY!<br>




      <br>




So why might we want to use
it... well, &nbsp;the gameboy+GBC sold 118 MILLION!... compared to
the ZX
spectrum's puny 5 million... the gamegears 10 million, the Master
system's 13 million... the Gameboy gives the 'real z80' systems a
spanking!<br>




      <br>




We can't use a normal Z80 assembler to develop for it,
but&nbsp;<a href="http://sun.hasenbraten.de/vasm/">Vasm</a>&nbsp;in
'OldStyle' mode will compile for it, just use the switch
'-gbz80' and it will compile compatible code!</td>




      <td><a href="https://www.chibiakumas.com/z80/Z80DevTools.php"><img style="border: 0px solid ; width: 128px; height: 128px;" src="theme/DevTools.png" alt=""></a></td>




      <td><a href="sources.7z"><img style="border: 0px solid ; width: 128px; height: 128px;" src="theme/File.png" alt=""></a></td>




      <td style="width: 128px;"><a href="https://youtu.be/Tn1rFUutkdo"><img style="border: 0px solid ; width: 128px; height: 128px;" src="theme/Videox.png" alt=""></a></td>




    </tr>




  
  
  
  </tbody>
</table>




<span style="font-weight: bold;"></span>
<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">The Gameboy Color
is just a Gameboy with a few 'power ups', The best thing is, if we
limit ourselves a bit, we can write games that
have full color on the GBC, but still play the same on the Classic
Gameboy!<br>




      <br>




Lets take a look at the GB and GBC specs!<br>




      <br>




Specs:<br>




      
      
      
      <table style="text-align: left;" border="1" cellpadding="2" cellspacing="2">




        <tbody>




          <tr>




            <td class="cyan" style="font-weight: bold;"></td>




            <td class="cyan" style="font-weight: bold;">Gameboy</td>




            <td class="cyan" style="font-weight: bold;">Gameboy
Color</td>




          </tr>




          <tr>




            <td>Cpu</td>




            <td>4mhz</td>




            <td>8mhz</td>




          </tr>




          <tr>




            <td>Ram</td>




            <td>8k</td>




            <td>32k</td>




          </tr>




          <tr>




            <td>Vram</td>




            <td>8k</td>




            <td>16k</td>




          </tr>




          <tr>




            <td>Resolution</td>




            <td>160x144</td>




            <td>160x144</td>




          </tr>




          <tr>




            <td>Max Tiles</td>




            <td>256 (8x8 px) - 360 onscreen</td>




            <td>512 (8x8 px)&nbsp;- 360 onscreen</td>




          </tr>




          <tr>




            <td>Max Sprites</td>




            <td>40 (8x8 px 10 per line)</td>




            <td>40 (8x8 px 10 per line)</td>




          </tr>




          <tr>




            <td>Colors</td>




            <td>4</td>




            <td>4 per palette - 8 palletes (0-7) from 32768 colors</td>




          </tr>




          <tr>




            <td>Sound chip</td>




            <td>GBZ80 PAPU</td>




            <td>GBZ80 PAPU</td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      <br>




      <br>




      </td>




      <td><img src="gameboy/GameBoy.jpg" alt=""><br>




      <span style="font-weight: bold;"></span><img src="gameboy/GameBoyColor.jpg" alt=""><span style="font-weight: bold;"><br>




      </span></td>




    </tr>




  
  
  
  </tbody>
</table>




<span style="font-weight: bold;"><big class="cyan"><br>
</big></span>
<table style="text-align: left; width: 100%;" border="0" cellpadding="2" cellspacing="2">







  <tbody>







    <tr>







      <td style="width: 128px;"><a href="GBZ80.pdf"><img style="border: 0px solid ; width: 128px; height: 128px;" src="theme/Cheatsheet.png" alt=""></a></td>







      <td style="text-align: right; vertical-align: top;"><span class="yume">If
you want to learn GBZ80 get the <a href="GBZ80.pdf">Cheatsheet</a>!
it has all the Z80 commands,&nbsp;but
higlights the ones missing on the GBZ80 - as well as the extra commands
that the GBZ80 posesses, and the commands with different bytecode...<br>
      <br>
You can use it for both your Z80 and GBZ80 development! </span></td>







      <td style="width: 64px;"><img src="theme/Yume128.png" alt=""></td>







    </tr>







  
  
  
  
  
  
  </tbody>
</table>
<br>
<span style="font-weight: bold;"><big class="cyan">It's Z80... but not as we know it!</big><br>




<br>




</span>So what's actually different, well, first you've got less
registers...
&nbsp;the 'GBZ80' (as we'll call it) has no shadow registers, I or
R... and
no index registers either!<br>




<br>




<br>




<table style="text-align: left;" border="1" cellpadding="2" cellspacing="0">




  <tbody>




    <tr>




      <td>&nbsp;</td>




      <td colspan="2" rowspan="1">Normal Registers</td>




      <td style="text-decoration: line-through;" colspan="2" rowspan="1"><span class="grey">Shadow Registers</span></td>




    </tr>




    <tr>




      <td>Accumulator</td>




      <td style="text-align: center;"><span style="font-weight: bold;" class="cyan">A</span>
      </td>




      <td style="text-align: center;"><span style="font-weight: bold;" class="cyan"><br>




      </span></td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">A'</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey"><br>




      </td>




    </tr>




    <tr>




      <td>flags</td>




      <td></td>




      <td style="text-align: center;">F</td>




      <td style="text-decoration: line-through;"></td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">F'</td>




    </tr>




    <tr>




      <td>HighLow Memory Location</td>




      <td style="text-align: center; font-weight: bold;" class="cyan">H</td>




      <td style="text-align: center; font-weight: bold;" class="cyan">L</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">H</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">L</td>




    </tr>




    <tr>




      <td>ByteCount</td>




      <td style="text-align: center;">B</td>




      <td style="text-align: center;">C</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">B</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">C</td>




    </tr>




    <tr>




      <td>DEstinaton</td>




      <td style="text-align: center;">D</td>




      <td style="text-align: center;">E</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">D</td>




      <td style="text-align: center; text-decoration: line-through;" class="grey">E</td>




    </tr>




    <tr>




      <td style="text-decoration: line-through;">Indirect
X - IX</td>




      <td style="text-align: center; text-decoration: line-through;">IXH</td>




      <td style="text-align: center; text-decoration: line-through;">IXL</td>




      <td style="text-align: center;"><br>




      </td>




      <td style="text-align: center;"><br>




      </td>




    </tr>




    <tr>




      <td style="text-decoration: line-through;">Indirect
Y - IY</td>




      <td style="text-align: center; text-decoration: line-through;">IYH</td>




      <td style="text-align: center; text-decoration: line-through;">IYL</td>




      <td style="text-align: center;"><br>




      </td>




      <td style="text-align: center;"><br>




      </td>




    </tr>




    <tr>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




    </tr>




    <tr>




      <td>Program Counter</td>




      <td>&nbsp;</td>




      <td>PC</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




    </tr>




    <tr>




      <td>Stack Pointer</td>




      <td>&nbsp;</td>




      <td>SP</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




    </tr>




    <tr>




      <td style="text-decoration: line-through;">Refresh</td>




      <td style="text-decoration: line-through;">&nbsp;</td>




      <td style="text-decoration: line-through;">R</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




    </tr>




    <tr>




      <td style="text-decoration: line-through;">Interrupt
point</td>




      <td style="text-decoration: line-through;">&nbsp;</td>




      <td style="text-decoration: line-through;">I</td>




      <td>&nbsp;</td>




      <td>&nbsp;</td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<br>




<span style="font-weight: bold;"><span class="magenta">LDIR</span></span><span class="magenta"> </span>type commands are gone, but
we can always fake them!<br>




<br>




Commands that load 2 bytes from a memory address like <span class="magenta" style="font-weight: bold;">LD
BC,(&amp;1234)</span> do not exist, we have to read in the
bytes separately<br>




<br>




There's
no <span class="magenta" style="font-weight: bold;">IN</span>
or <span class="magenta" style="font-weight: bold;">OUT</span>
commands, not that it matters, as devices are memory
mapped, so we just read or write to them in their memory locations.<br>




<br>




oh and thanks to a bug,<span class="yellow"> </span><span class="yellow" style="font-weight: bold;">INC xx</span><span class="yellow"> </span>and <span class="yellow" style="font-weight: bold;">DEC xx</span> with BC, DE
or HL can corrupt the
sprite memory, just for good measure!<br>




<br>




The <span style="font-weight: bold;" class="yellow">HALT</span>
command also has a quirk!, if interrupts are disabled, the command will
skip, however the CPU also skips the following command, so put a NOP
after HALT<br>




<br>




We do have some new exciting commands... <span class="cyan" style="font-weight: bold;">SWAP</span> A will swap the
top
nibble and bottom nibble of A (or any other register!)<br>




<br>




<span class="cyan" style="font-weight: bold;">LD
($FF00+C),A</span> ... will use C as part of the address to write
to - this is
the equivalent of OUT (C),a... as the memory mapped devices are in the
&amp;FF00-&amp;FF80 range.<br>




<br>




We also have <span class="cyan" style="font-weight: bold;">LDI</span>
for Load and Increment, and <span class="cyan" style="font-weight: bold;">LDD</span> for load and
decriment... it kind of makes up for losing LDIR!<br>




<br>




I've started making a <a href="gbz80.html">Cheatsheet</a>,
which already contains all the new and changed commands...but if you're
careful, and only use commands supported by the Z80 and GBZ80, you can
create common code that can compile for either system!<br>




<br>




There are interrupts, but there is no interrupt mode 1 or 2... RST0-7
exist, but &amp;0038 is not called by any interrupts... GBZ80
interrupts call addresses &amp;0040-&amp;0060 in rom.<br>




<br>




<span style="font-weight: bold;"><big class="cyan">Console
graphics hardware - Tiles and Sprites!<br>




</big></span>This section is a general description, and not
Gameboy specific, skip to
the next chapter if you know the concept of tiles and sprite layers!<br>




<br>




<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">The
Gameboy,Gamegear and Mastersystem screens do not
work like they do on computers like the CPC<br>




Graphics are not just 'bytes' in a memory address... &nbsp;The
screen is made up of a 'Tile Layer' and a 'Sprite Layer'<br>




      <br>




To explain Tiles and sprites, lets look at our imaginary game shown to
the right 'The Super Yuusha Siblings', on a theoretical game system the
'GameChibi'... Just to be very clear, we looking at this as a concept,
not the actual layout of the gameboy!<br>




      <br>




Looking at our example, We have a level with some grass, blocks, and
some collectable 'stars'... our hero, Yume is controlled by the
player...<br>




      </td>




      <td><img src="res/SpriteExample_1.png" alt=""></td>




    </tr>




    <tr>




      <td style="vertical-align: top;">The screen is made
up of the Tile layer, and the Sprite
Layer,<br>




      <br>




Usually Sprites are drawn above the Tiles... but sometimes they may be
drawn below.<br>




      <br>




It's also possible we could use sprites for the stars.. but sprites are
very limited, so the object doesn't move, then tiles will do the job...
we can even animate the stars by switching the tile between different
patterns </td>




      <td><img src="res/SpriteExample_2.png" alt=""></td>




    </tr>




    <tr>




      <td style="vertical-align: top;">The tile array on
the systems we'll be looking at is
made up of 8x8 tiles... the array is a 'grid' of these tiles, so the
tiles must line up, a block cannot be at a 'half way boundary'<br>




      <br>




Tiles are defined by a number (usually 0-255)... we define the bitmap
(image) data for that tile (we'll call it a pattern), then tell the
hardware what positions in the tile array to use that pattern.<br>




      <br>




In our example, the black background is pattern 0 ... the blocks are
pattern 1... the grass is pattern 2... and the stars are pattern 3<br>




      <br>




Our 'GameChibi' console has a tile array of 8x8... and 64 bytes is used
to define the tile grid...<br>




So to define the stars, we need to set memory locations 10,20 and 15 of
the tile array to byte '3'<br>




      <br>




A real system usually has a tile array bigger than the screen (maybe
just by one row and one coumn)... this is to allow smooth scrolling of
the screen, where two tiles are 'half shown'<br>




      <br>




Now in the case of our&nbsp;'GameChibi' system, with it's 64 tile
screen, and 256 pattern definitions, we could just set every visible
tile to a different pattern, and treat the screen as a plain bitmap
again... We can do that on the MSX1, but unfortunately the Gameboy and
Mastersystem have too few tiles for their screen size, so some parts of
the screen must contain the same tile!</td>




      <td><img src="res/SpriteExample_3.png" alt=""></td>




    </tr>




    <tr>




      <td>Because our system is using hardware sprites, we have
to design our game sprites in a way that can be drawn with the hardware
sprites... for example lets look at our Yume sprite... if our
'GameChibi' used 8x8 hardware sprites, we would have to use 48 of them
to make this image!... we can save 6 (marked green)... these have no
data, so we can just not draw them...<br>




      <br>




When it comes to moving our character, the software will have to move
the hardware sprites all together, so the user does not realise they
are made up of many sprites!... on systems with more onscreen colors
than sprite colors, two or more sprites may be overlapped to make the
sprite appear more colorful<br>




      <br>




Most systems will have one color (usually 0) which marks the
transparent colour.<br>




      <br>




but there is a problem! with software sprites on a bitmap screen, we
can draw as much as we want, it will just get slow.... but with
hardware sprites, we have a fixed limit of how many sprites can be
shown onscreen at once! sounds bad? well actually it's worse, even
though a system like the gameboy can show 40 sprites onscreen, there
can only be 10 on a line... if more than 10 appear on the same line,
some will flicker, or not appear... there's nothing we can do about it,
we just have to design our game to avoid this problem!</td>




      <td><img src="res/SpriteExample_5.png" alt=""></td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<span style="font-weight: bold;"><big class="cyan">The
Gameboy Color, for extra power!</big></span><br>




<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td>The gameboy color has many enhancements,<br>




We can switch the CPU into high speed mode, for twice the CPU power and
we have extra ram banks we can page in.<br>




      <br>




Most importantly the GBC adds more graphics ability, with twice the
tile definitions (512) and 8 'palettes' of four colours <br>




      <br>




Colour palettes are defined with a 5 bits per channel in the format
&nbsp;-BBBBBGG GGGRRRRR<br>




      <br>




Turning on the 'Second bank of tiles' (the extra 256) and setting the
color palette is done by paging in the second 'GBC only' Vram Bank</td>




      <td></td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<span style="font-weight: bold;">
</span><span style="font-weight: bold;"><big class="cyan">Gameboy Cartridge Rom format - and Interrupt
calls!<br>




</big></span>
<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">The cartridge is
loaded into the system memory as the ROM... The first
&amp;160 bytes of the cartridge contain the RST calls and GBZ80
Interrupt calls<br>




      <br>




Next come the header, which tells the gameboy
what the cartridge contains... there is also a checksum, which must be
correct for the game to work on a real gameboy - though it should work
on emulators without it! (the tool rgbfix.exe will work out the
checksum for you!)<br>




      <br>




A note on the interrupts between &amp;0040-&amp;0060:<br>




Interrupts
can be enabled or disabled as needed, but it's best to put a
&nbsp;'RETI'
&nbsp;(Return and enable interupts) at &amp;0040-&amp;0060</td>




      <td><br>




      
      
      
      <table style="width: 600px;" border="0" cellspacing="0">




        <tbody>




          <tr>




            <td style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">From</td>




            <td style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">To</td>




            <td style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">Meaning</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0000</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>0007</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST0</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0008</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>000F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST1</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0010</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>0017</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST2</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0018</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>001F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST3</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0020</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>0027</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST4</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0028</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>002F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST5</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0030</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>0037</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST6</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff" height="17"><b><font>0038</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ccffff"><b><font>003F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ccffff"><font>Z80
RST7</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99" height="17"><b><font>0040</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99"><b><font>0047</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99"><font>Interrupt:Vblank</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99" height="17"><b><font>0048</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99"><b><font>004F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99"><font>Interrupt:LCD-Stat</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99" height="17"><b><font>0050</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99"><b><font>0057</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99"><font>Interrupt:Timer</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99" height="17"><b><font>0058</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99"><b><font>005F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99"><font>Interrupt:Serial</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99" height="17"><b><font>0060</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffcc99"><b><font>0067</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99"><font>Interrupt:Joypad</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#cccccc" height="17"><b><font>0068</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#cccccc"><b><font>00FF</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#cccccc"><font>unused</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffff66" height="17"><b><font>0100</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffff66"><b><font>0103</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffff66"><font>Entry
point (start of program)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0104</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0133</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Nintendo
logo (must match rom logo)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0134</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0142</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Game
Name (Uppercase)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0143</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0143</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Color
gameboy flag (&amp;80 = GB+CGB,&amp;C0 = CGB only)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0144</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0145</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Game
Manufacturer code</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0146</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0146</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Super
GameBoy flag (&amp;00=normal, &amp;03=SGB)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0147</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0147</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Cartridge
type (special upgrade hardware) (0=normal ROM)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0148</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0148</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Rom
size (0=32k, 1=64k,2=128k etc)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>0149</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>0149</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Cart
Ram size (0=none,1=2k 2=8k, 3=32k)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>014A</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>014A</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Destination
Code (0=JPN 1=EU/US)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>014B</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>014B</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Old
Licensee code (must be &amp;33 for SGB)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>014C</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>014C</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Rom
Version Number (usually 0)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>014D</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>014D</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Header
Checksum - &lsquo;ones complement&rsquo; checksum of bytes
0134-014C<br>




not needed for emulators</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee" height="17"><b><font>014E</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#c8a3ee"><b><font>014F</font></b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#c8a3ee"><font>Global
Checksum &ndash; 16 bit sum of all rom bytes (except 014E-014F)<br>




unused by gameboy</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffff66" height="17"><b><font>0150</font></b></td>




            <td style="color: rgb(0, 0, 0);" sdnum="1041;0;@" align="left" bgcolor="#ffff66"><b>&hellip;</b></td>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#ffff66"><font>Game
Code!</font></td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      </td>




    </tr>




  
  
  
  </tbody>
</table>




<span style="font-weight: bold;">
</span><span style="font-weight: bold;"><big class="cyan">Gameboy Memory Map</big></span><br>




<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">The Rom cartridge
(and its header) take up the first
&amp;8000 bytes of memory,<br>




      <br>




The 8k of ram is accessible at &amp;C000-&amp;DFFF... a 'shadow
copy' is also at &amp;E000-&amp;FDFF (some cartridges have
extra ram at this address)<br>




      <br>




      </td>




      <td>
      
      
      
      <table style="color: rgb(0, 0, 0);" border="0" cellspacing="0">




        <tbody>




          <tr>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" height="66" valign="middle"><b><font>0000</font></b></td>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" height="66" valign="middle"><b><font>3FFF</font></b></td>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-right: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" valign="middle"><font>16KB
ROM Bank 00 (in cartridge, fixed
at bank 00)</font></td>




          </tr>




          <tr>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" height="66" valign="middle"><b><font>4000-</font></b></td>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" height="66" valign="middle"><b><font>7FFF</font></b></td>




            <td style="border-top: 1px solid rgb(0, 0, 0); border-right: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#e6e6e6" valign="middle"><font>16KB
ROM Bank 01..NN (in cartridge,
switchable bank number)</font></td>




          </tr>




          <tr>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">8000</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">8FFF</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0);">VRAM:
Tiles / Sprites</td>




          </tr>




          <tr>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">9000</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">97FF</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0);">VRAM:
Tiles Alt</td>




          </tr>




          <tr>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">9800</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">9BFF</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0);">VRAM:
Tilemap 1</td>




          </tr>




          <tr>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">9C00</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0); font-weight: bold;">9FFF</td>




            <td style="background-color: rgb(241, 251, 209); color: rgb(0, 0, 0);">VRAM:
Tilemap 2</td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99" height="20" valign="middle"><b><font>A000</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99" valign="middle"><b><font>BFFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffcc99" valign="middle"><font>8KB
External RAM (in cartridge,
switchable bank, if any)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9efd9e" height="20"><b><font>C000</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9efd9e"><b><font>CFFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9efd9e"><font>4KB Work
RAM Bank 0 (WRAM)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#23ff23" height="20"><b><font>D000</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#23ff23"><b><font>DFFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#23ff23"><font>4KB Work
RAM Bank 1 (WRAM) (switchable bank 1-7 in
CGB Mode)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffff66" height="20"><b><font>E000</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffff66"><b><font>FDFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#ffff66"><font>Same as
C000-DDFF (ECHO) (typically not used)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9999ff" height="20"><b><font>FE00</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9999ff"><b><font>FE9F</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#9999ff"><font>Sprite
Attribute Table (OAM) (Can&rsquo;t
change during screen redraw)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left" height="20"><b><font>FEA0</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left"><b><font>FEFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left"><font>Not
Usable</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#99ccff" height="20"><b><font>FF00</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#99ccff"><b><font>FF7F</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(0, 0, 0);" align="left" bgcolor="#99ccff"><font>I/O Ports</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left" height="20"><b><font>FF80</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left"><b><font>FFFE</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" align="left"><font>High
RAM (HRAM) (Stack)</font></td>




          </tr>




          <tr>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(255, 255, 255);" align="left" bgcolor="#000000" height="20"><b><font>FFFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(255, 255, 255);" align="left" bgcolor="#000000"><b><font>FFFF</font></b></td>




            <td style="border: 1px solid rgb(0, 0, 0); color: rgb(255, 255, 255);" align="left" bgcolor="#000000"><font>Interrupt
Enable Register</font></td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      </td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<br>




<span style="font-weight: bold;"></span><span style="font-weight: bold;"><big class="cyan">Hardware
ports - AKA 'Where's my OUT command gone?'<br>




</big></span>As mentioned before, the Gameboy has no IN or
Out commands, there is a bank of hardware regsiters memory mapped
between &amp;FF00 and &amp;FF80... just write or read from
these memory locations to have the hardware effect... we'll cover the
details of these in later tutorials<br>




<br>




<table border="1" cellspacing="0">




  <tbody>




    <tr>




      <td align="left" bgcolor="#000000" height="19"><b><font color="#ffffff">Section</font></b></td>




      <td align="center" bgcolor="#000000"><b><font color="#ffffff">Addr</font></b></td>




      <td align="left" bgcolor="#000000"><b><font color="#ffffff">Name</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#000000"><font color="#ffffff">Bits</font></td>




      <td align="left" bgcolor="#000000"><font color="#ffffff">Bit Meaning</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#00ff7c" height="19"><b><font color="#000000">Joy</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF00 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">P1/JOYP - Joypad (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">--BD3210</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">B=Buttons D=Direction
3210=buttons DULR SSBA</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#b3b3b3" height="19"><b><font color="#000000">Serial</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF01 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">SB - Serial transfer
data (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">8 Bits of data</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#b3b3b3" height="19"><b><font color="#000000">Serial</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF02 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">SC - Serial Transfer
Control (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">S-----SC</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">SC - Serial Transfer
Control (R/W)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#00cccc" height="18"><b><font color="#000000">Timer</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF04 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">DIV - Divider
Register (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#00cccc" height="18"><b><font color="#000000">Timer</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF05 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">TIMA - Timer
counter (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#00cccc" height="18"><b><font color="#000000">Timer</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF06 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">TMA - Timer
Modulo (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#00cccc" height="19"><b><font color="#000000">Timer</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF07 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">TAC - Timer Control (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">-----SCC</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">S=Stary CC=Clockspeed</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ffff00" height="19"><b><font color="#000000">INT</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF0F </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">IF - Interrupt Flag (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF10 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR10 - Channel 1 (Tone
&amp; Sweep) Sweep register (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">-TTTDNNN</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">T=Time,D=direction,N=Numberof
shifts </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF11 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000"> NR11 - Channel 1 (Tone
&amp; Sweep) Sound length/Wave pattern duty (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">DDLLLLLL</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">L=Length D=Wave pattern
Duty</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF12 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR12 - Channel 1 (Tone
&amp; Sweep) Volume Envelope (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">VVVVDNNN</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">C1 Volume / Direction
0=down / envelope Number (fade speed)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF13 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR13 - Channel 1 (Tone
&amp; Sweep) Frequency lo (Write Only)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">LLLLLLLL</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">pitch L</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF14 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR14 - Channel 1 (Tone
&amp; Sweep) Frequency hi (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">IC---HHH</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">C1 Initial / Counter
1=stop / pitch H</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF16 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR21 &ndash; Channel
2 (Tone) Sound Length/Wave Pattern Duty (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">DDLLLLLL</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">L=Length D=Wave pattern
Duty</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF17 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR22 - Channel 2 (Tone)
Volume Envelope (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">VVVVDNNN</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">C1 Volume / Direction
0=down / envelope Number (fade speed)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF18</font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR23 - Channel 2 (Tone)
Frequency lo data (W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">LLLLLLLL</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">pitch L</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF19 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR24 - Channel 2 (Tone)
Frequency hi data (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">IC---HHH</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">C1 Initial / Counter
1=stop / pitch H</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF1A </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR30 - Channel 3 (Wave
Output) Sound on/off (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">E-------</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">1=on</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF1B </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR31 - Channel 3 (Wave
Output) Sound Length</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">NNNNNNNN</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">Higher is shorter - no
effect unles C=1 in FF1E</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF1C </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR32 - Channel 3 (Wave
Output) Select output level (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">-VV-----</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">VV=Volume (0=off 1=max
2=50% 3=25%)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF1D</font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR33 - Channel 3 (Wave
Output) Frequency's lower data (W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">LLLLLLLL</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">Low frequency</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF1E </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR34 - Channel 3 (Wave
Output) Frequency's higher data (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">RC---HHH</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">H=high frequency
C=counter repeat (loop) R=Restart sample</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF20</font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR41 - Channel 4 (Noise)
Sound Length (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">---LLLLL</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">L=Length</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF21 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR42 - Channel 4 (Noise)
Volume Envelope (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">VVVVDNNN</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">Volume / Direction
0=down / envelope Number (fade speed)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF22 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR43 - Channel 4 (Noise)
Polynomial Counter (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">SSSSCDDD</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">Shift clock frequency
(pitch) / Counter Step 0=15bit 1=7bit (sounds eletronic)/ Dividing
ratio (roughness)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF23 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR44 - Channel 4 (Noise)
Counter/consecutive; Inital (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">IC------</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">C1 Initial / Counter
1=stop</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF24 </font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR50 - Channel control /
ON-OFF / Volume (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">-LLL-RRR</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">Channel volume (7=loud)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF25 </font></b></td>




      <td align="left" bgcolor="#e6e6ff"><b><font color="#000000">NR51 - Selection of
Sound output terminal (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff"><font color="#000000">LLLLRRRR</font></td>




      <td align="left" bgcolor="#e6e6ff"><font color="#000000">Channel 1-4 L / Chanel
1-4R (1=on)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="19"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF26</font></b></td>




      <td align="left" bgcolor="#e6e6e6"><b><font color="#000000">NR52 - Sound on/off</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6e6"><font color="#000000">A---4321</font></td>




      <td align="left" bgcolor="#e6e6e6"><font color="#000000">read Channel 1-4 status
or write All channels on/off (1=on)</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ff950e" height="36" valign="top"><b><font color="#000000">Sound</font></b></td>




      <td align="center" bgcolor="#ff8080" valign="top"><b><font color="#000000">FF30 &ndash; FF3F</font></b></td>




      <td align="left" bgcolor="#e6e6ff" valign="top"><b><font color="#000000">Wave Pattern RAM</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#e6e6ff" valign="top"><font color="#000000">HHHHLLLL</font></td>




      <td align="left" bgcolor="#e6e6ff" valign="top"><font color="#000000">32 4 bit samples</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#355e00" height="19"><b><font color="#000000">LCD</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF40 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">LCDC - LCD Control (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">EWwBbOoC<br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">O=Object sprite size 1=8x16<br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#355e00" height="19"><b><font color="#000000">LCD</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF41</font></b></td>




      <td align="left" bgcolor="#ffffff" valign="middle"><b><font color="#000000">STAT
- LCDC Status (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF42 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">$00 ; SCY &ndash;
Tile Scroll Y</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF43 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">$00 ; SCX &ndash;
Tile Scroll X</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#355e00" height="19"><b><font color="#000000">LCD</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF44 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000"> LY - LCDC Y-Coordinate
(R) - LCD Y Line (0-153 144+ are V-Blank)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#355e00" height="19"><b><font color="#000000">LCD</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF45 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">LYC - LY Compare (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#33a3a3" height="19"><b><font color="#000000">RAM</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF46</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">DMA - DMA Transfer and
Start Address (W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">High byte of DMA - must be executed from &amp;FF80-FFFE<br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#e6e6e6"><b><font color="#000000">FF47 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">BGP - BG Palette Data
(R/W) - Non CGB Mode Only</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#6b0094" height="19"><b><font color="#000000">Sprite</font></b></td>




      <td align="center" bgcolor="#e6e6e6"><b><font color="#000000">FF48 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">OBP0 - Object Palette 0
Data (R/W) - Non CGB Mode Only</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#6b0094" height="19"><b><font color="#000000">Sprite</font></b></td>




      <td align="center" bgcolor="#e6e6e6"><b><font color="#000000">FF49 </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">OBP1 - Object Palette 1
Data (R/W) - Non CGB Mode Only</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF4A </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">WY - Window Y Position
(R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FF4B </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">WX- Window X Position
minus 7 (R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#996633" height="19"><b><font color="#000000">CPU</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF4D</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">KEY1 - CGB Mode Only -
Prepare Speed Switch</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">C------P</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">C=Current speed
P=prepare switch</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#6b4794" height="19"><b><font color="#000000">VRAM</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF4F</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">VBK - CGB Mode Only -
VRAM Bank</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">-------B</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">B=Bank</font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#b3b3b3" height="19"><b><font color="#000000">COM</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF56</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">RP - CGB Mode Only -
Infrared Communications Port</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF68</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">BCPS/BGPI - CGB Mode
Only - Background Palette Index</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ccffff" height="19"><b><font color="#000000">Tile</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF69</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">BCPD/BGPD - CGB Mode
Only - Background Palette Data</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#6b0094" height="19"><b><font color="#000000">Sprite</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF6A</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">OCPS/OBPI - CGB Mode
Only - Sprite Palette Index</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#6b0094" height="19"><b><font color="#000000">Sprite</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF6B</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">OCPD/OBPD - CGB Mode
Only - Sprite Palette Data</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000"><br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#33a3a3" height="19"><b><font color="#000000">RAM</font></b></td>




      <td align="center" bgcolor="#9999ff"><b><font color="#000000">FF70</font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">SVBK - CGB Mode Only -
WRAM Bank (bits 0-3 =0-2)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">-----BBB<br>




      </font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">BBB=Bank 1-7 (0 also pages in bank 1)<br>




      </font></td>




    </tr>




    <tr>




      <td align="left" bgcolor="#ffff00" height="19"><b><font color="#000000">INT</font></b></td>




      <td align="center" bgcolor="#ff8080"><b><font color="#000000">FFFF </font></b></td>




      <td align="left" bgcolor="#ffffff"><b><font color="#000000">IE - Interrupt Enable
(R/W)</font></b></td>




      <td sdnum="1041;0;@" align="left" bgcolor="#ffffff"><font color="#000000">---JSTLV</font></td>




      <td align="left" bgcolor="#ffffff"><font color="#000000">J=Joypad S=Serial
T=Timer L=Lcd stat V=vblank</font></td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<br>




<br>




<span style="font-weight: bold;"><big class="cyan">Bankswitching
on cartridges with MBC1+</big></span><br>




<table style="text-align: left; width: 100%;" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">Larger cartridges
can have more than 32k rom,
and even extra RAM built into them (With battery backup!)<br>




We switch cartridge RAM/ROM bank by writing to specific address ranges
within the 'ROM'... this tells the cartridge to change bank...<br>




Good example addresses are shown below... though actually a range of
addresses will have the same effect</td>




      <td>
      
      
      
      <table border="0" cellspacing="0">




        <colgroup width="265"></colgroup> <tbody>




          <tr>




            <td style="background-color: rgb(255, 255, 255); font-weight: bold; color: rgb(0, 0, 0);" align="left" height="17"><font>MBC1 Bank Swapper</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#e5d9ff" height="17" valign="middle"><font>0000
(Write) &ndash; Ram enable (&amp;0A)</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#e5d9ff" height="32" valign="middle"><font>2000
(Write) &ndash; Rom Bank Number<br>




3000 (Write) &ndash; Bit 8 of MBC5 ROM Bank</font></td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0);" align="left" bgcolor="#e5d9ff" height="45" valign="middle"><font>4000
(Write) &ndash; Ram Bank Number<br>




6000 (Write) &ndash; Rom/Ram Mode Select<br>




            </font></td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      </td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<span style="font-weight: bold;"><big class="cyan">Gameboy
Joystick port<br>




</big></span>
<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td style="vertical-align: top;">Joypad reading is
all done with memory address &amp;FF00<br>




      <br>




Only Bits 0-3 in this address contain the state of the buttons, we
first need to select which half of the joystick we want to read.<br>




      <br>




If we write %11101111 to &amp;FF00 (Bit 4 is zero) ... we will
select the diirection controls... and the next read from &amp;FF00
will get&nbsp;Down, Up, Left, Right in bits 0-3<br>




      <br>




If we write %11011111 to &amp;FF00 (Bit 5 is zero) ... we will
select
the&nbsp;button controls... and the next read from &amp;FF00
will get Start, Select, Button B, Button A in bits 0-3</td>




      <td>
      
      
      
      <table style="text-align: left;" border="1" cellpadding="2" cellspacing="2">




        <tbody>




          <tr>




            <td style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">Address</td>




            <td style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">Bit</td>




            <td colspan="2" rowspan="1" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); font-weight: bold;">Purpose</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">&amp;FF00</td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">7</td>




            <td colspan="2" rowspan="1" style="color: rgb(0, 0, 0); background-color: rgb(102, 102, 102);">Unused</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">6</td>




            <td colspan="2" rowspan="1" style="color: rgb(0, 0, 0); background-color: rgb(102, 102, 102);">Unused</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">5</td>




            <td colspan="2" rowspan="1" style="color: rgb(0, 0, 0); background-color: rgb(51, 204, 0);">Read
Buttons</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">4</td>




            <td colspan="2" rowspan="1" style="color: rgb(0, 0, 0); background-color: rgb(255, 102, 102);">Read
Directions</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">3</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(255, 204, 204);">Down</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(102, 255, 153);">Start</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">2</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(255, 204, 204);">Up</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(102, 255, 153);">Select</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">1</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(255, 204, 204);">Left</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(102, 255, 153);">Button
B</td>




          </tr>




          <tr>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);"></td>




            <td style="color: rgb(0, 0, 0); font-weight: bold; background-color: rgb(192, 192, 192);">0</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(255, 204, 204);">Right
&nbsp; &nbsp; &nbsp;</td>




            <td style="color: rgb(0, 0, 0); background-color: rgb(102, 255, 153);">Button
A</td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      </td>




    </tr>




  
  
  
  </tbody>
</table>




<br>




<span style="font-weight: bold;"><big class="cyan">Gameboy
Sprite Memory</big></span><br>




<span style="font-weight: bold;"></span>
<table style="text-align: left; width: 100%;" border="1" cellpadding="2" cellspacing="2">




  <tbody>




    <tr>




      <td>Sprite Data is stored from &amp;FE00 onwards, there
are 40 sprites, and each definition uses 4 consecutive bytes...<br>




      <br>




For Example, Sprite 0's bytes are highlighted in black... it has a Y
co-ordinate, an X co-ordinate, a Tile Number, and tile Attributes<br>




      <br>




Y and X are offset, so you can have a sprite partially off the screen,
You need to set XY to (8,16) to get the top corner of the screen (0,0)<br>




      <br>




Attributes: &nbsp;<br>




      
      
      
      <table style="text-align: left;" border="1" cellpadding="4" cellspacing="2">




        <tbody>




          <tr>




            <td class="magenta" style="text-align: center; font-weight: bold;">7</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp;
&nbsp; &nbsp;6&nbsp; &nbsp; &nbsp;</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp;
&nbsp; &nbsp;5&nbsp; &nbsp; &nbsp;</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp;
&nbsp; &nbsp;4&nbsp; &nbsp; &nbsp;</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">3</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp;
2&nbsp;&nbsp;</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp;
1&nbsp;&nbsp;</td>




            <td class="magenta" style="text-align: center; font-weight: bold;">&nbsp; 0
&nbsp;</td>




          </tr>




          <tr>




            <td style="text-align: center;">Tile-Sprite <br>




Priority</td>




            <td style="text-align: center;">Y-flip</td>




            <td style="text-align: center;">X-flip</td>




            <td style="text-align: center;">GB-Pal</td>




            <td style="text-align: center;">CGB-Vbank</td>




            <td style="text-align: center;" colspan="3" rowspan="1">CGB-Palette</td>




          </tr>




        
        
        
        </tbody>
      
      
      
      </table>




      <br>




      </td>




      <td><img style="width: 645px; height: 292px;" src="gameboy/SpriteMemory.png" alt=""></td>




    </tr>




  
  
  
  </tbody>
</table>




<span style="font-weight: bold;"><big class="cyan"><br>




<br>




</big></span><big>
Gameboy and Gameboy Color Programming Tutorials:<br>




</big><a href="platform.php#LessonP9">P9 - Tilemap
graphics on the
Gameboy and Gameboy Color </a><a href="https://www.chibiakumas.com/z80/platform.php#LessonP8"><br>




</a><br>




<big>General Z80 Assembly Tutorials:</big><br>




<a href="https://www.chibiakumas.com/z80/"><span style="font-weight: bold;">B. Beginner series - Learn the
basics</span></a><br style="font-weight: bold;">




<a href="https://www.chibiakumas.com/z80/advanced.php"><span style="font-weight: bold;">A. Advanced series - In more
detail</span></a><br style="font-weight: bold;">




<a href="https://www.chibiakumas.com/z80/multiplatform.php"><span style="font-weight: bold;">M. Multiplatform series -
programming methods that work on all systems</span></a><br style="font-weight: bold;">




<br>




<br>




<br>




<div style="text-align: center;">
Visit <a href="https://www.chibiakumas.com/">www.ChibiAkumas.com</a>
to get my games and their source code! | <a href="http://www.patreon.com/akuyou">Support me on patreon</a><br>




</div>




<br>




</body>
</html>
