hammered.gb             FX Hammer Editor ROM v1.1
fxbank.sav              SoundFX Bank for testing (transfer to card SRAM)

fxtest-1.gb             SoundFX Demo ROM (music with no samples)
fxtest-2.gb             SoundFX Demo ROM (music uses sample player)

using_carillon.html     This document should have all the information needed
                        for using the music and sound FX routines


full-ex1.asm            Example for playing FX and music with no samples
full-ex2.asm            Example for playing FX and music which uses samples

fruitless.bin           Music Bank for testing (no samples)

oldschool.bin           Music Bank and
oldschool.sam           Sample Bank for testing

fxbank.bin              SoundFX Bank for testing (10 sounds)

Aleksi Eeben (aleksi@cncd.fi)
